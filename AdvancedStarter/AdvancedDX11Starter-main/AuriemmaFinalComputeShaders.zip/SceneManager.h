#pragma once
enum class SceneState
{
	Main,
	Fractal
};